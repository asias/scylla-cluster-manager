DEFAULT_METRIC_PATTERNS = [
    '*cache*',
    '*disk*',
    '*transport*',
    '*netlink*',
    '*network*',
    '*storage_proxy*',
    '*la*',
    '*reactor*',
    '*idle*',
    '*interface*',
    '*memory*',
    '*cpu*',
]
