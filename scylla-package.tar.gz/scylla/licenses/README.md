## Note on licenses directory

The files in this directory represent licenses that apply to portions of
the work. See each source file for applicable licenses.

The work in whole is licensed under the Affero GPL, version 3 or above.  See
the LICENSE.AGPL file in the top-level directory.